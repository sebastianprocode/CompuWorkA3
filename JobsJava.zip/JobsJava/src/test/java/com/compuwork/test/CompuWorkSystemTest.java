package com.compuwork.test;

import com.compuwork.model.Empleado;
import com.compuwork.model.EmpleadoPermanente;
import com.compuwork.model.EmpleadoTemporal;
import com.compuwork.model.Departamento;
import com.compuwork.service.EmpleadoService;
import com.compuwork.service.DepartamentoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Suite de pruebas unitarias para el sistema CompuWork HR.
 * Valida el cálculo correcto de salarios, asignación de departamentos y reportes.
 * 
 * Principio SOLID: Single Responsibility - Esta clase solo se encarga de 
 * ejecutar las pruebas unitarias del sistema.
 */
class CompuWorkSystemTest {
    
    private EmpleadoService empleadoService;
    private DepartamentoService departamentoService;
    private Departamento departamentoTI;
    private Departamento departamentoRRHH;
    
    @BeforeEach
    void setUp() {
        // Inicializar servicios
        empleadoService = new EmpleadoService();
        departamentoService = new DepartamentoService();
        
        // Crear departamentos de prueba
        departamentoTI = departamentoService.crearDepartamento("Tecnología", "Departamento de TI");
        departamentoRRHH = departamentoService.crearDepartamento("Recursos Humanos", "Gestión de personal");
    }
    
    @Test
    @DisplayName("Prueba de cálculo de salario para empleado permanente")
    void testCalculoSalarioEmpleadoPermanente() {
        // Crear empleado permanente con 3 años de antigüedad
        LocalDate fechaContratacion = LocalDate.now().minusYears(3);
        EmpleadoPermanente empleado = (EmpleadoPermanente) empleadoService.crearEmpleadoPermanente(
                "Juan Pérez", 5000.0, fechaContratacion);
        
        // Salario base: 5000.0
        // Bono por antigüedad: 5000.0 * 0.05 * 3 = 750.0
        // Salario total esperado: 5750.0
        double salarioEsperado = 5000.0 + (5000.0 * 0.05 * 3);
        
        assertEquals(salarioEsperado, empleado.calcularSalarioTotal(), 0.01,
                "El salario total debe incluir el bono por antigüedad");
        
        assertEquals(750.0, empleado.calcularBonoAntiguedad(), 0.01,
                "El bono de antigüedad debe ser del 5% por año");
        
        assertTrue(empleado.tieneBeneficiosAdicionales(),
                "Empleado con más de 2 años debe tener beneficios adicionales");
    }
    
    @Test
    @DisplayName("Prueba de cálculo de salario para empleado temporal")
    void testCalculoSalarioEmpleadoTemporal() {
        LocalDate fechaContratacion = LocalDate.now().minusMonths(6);
        LocalDate fechaFinContrato = LocalDate.now().plusMonths(6);
        
        EmpleadoTemporal empleado = (EmpleadoTemporal) empleadoService.crearEmpleadoTemporal(
                "María García", 4500.0, fechaContratacion, fechaFinContrato);
        
        // Para empleados temporales, el salario total es igual al salario base
        assertEquals(4500.0, empleado.calcularSalarioTotal(), 0.01,
                "El salario de empleado temporal debe ser igual al salario base");
        
        assertTrue(empleado.isContratoVigente(),
                "El contrato debe estar vigente");
        
        assertTrue(empleado.getDiasRestantesContrato() > 0,
                "Debe haber días restantes en el contrato");
    }
    
    @Test
    @DisplayName("Prueba de asignación y cambio de empleados entre departamentos")
    void testAsignacionCambioDepartamentos() {
        // Crear empleado
        Empleado empleado = empleadoService.crearEmpleadoPermanente(
                "Carlos López", 5500.0, LocalDate.now().minusYears(2));
        
        // Asignar al departamento TI
        assertTrue(empleadoService.transferirEmpleado(empleado.getId(), departamentoTI),
                "Debe poder transferir empleado a departamento TI");
        
        assertEquals(departamentoTI, empleado.getDepartamento(),
                "El empleado debe estar asignado al departamento TI");
        
        assertTrue(departamentoTI.getEmpleados().contains(empleado),
                "El departamento TI debe contener al empleado");
        
        // Transferir a otro departamento
        assertTrue(empleadoService.transferirEmpleado(empleado.getId(), departamentoRRHH),
                "Debe poder transferir empleado a otro departamento");
        
        assertEquals(departamentoRRHH, empleado.getDepartamento(),
                "El empleado debe estar asignado al nuevo departamento");
        
        assertFalse(departamentoTI.getEmpleados().contains(empleado),
                "El departamento anterior ya no debe contener al empleado");
        
        assertTrue(departamentoRRHH.getEmpleados().contains(empleado),
                "El nuevo departamento debe contener al empleado");
    }
    
    @Test
    @DisplayName("Prueba de generación correcta de promedios en reportes de desempeño")
    void testPromediosDesempeno() {
        // Crear empleados con diferentes evaluaciones
        Empleado empleado1 = empleadoService.crearEmpleadoPermanente(
                "Empleado 1", 5000.0, LocalDate.now().minusYears(1));
        Empleado empleado2 = empleadoService.crearEmpleadoPermanente(
                "Empleado 2", 5500.0, LocalDate.now().minusYears(2));
        
        // Asignar al mismo departamento
        empleadoService.transferirEmpleado(empleado1.getId(), departamentoTI);
        empleadoService.transferirEmpleado(empleado2.getId(), departamentoTI);
        
        // Agregar evaluaciones
        empleadoService.agregarEvaluacionDesempeno(empleado1.getId(), 8);
        empleadoService.agregarEvaluacionDesempeno(empleado1.getId(), 9);
        // Promedio empleado 1: (8 + 9) / 2 = 8.5
        
        empleadoService.agregarEvaluacionDesempeno(empleado2.getId(), 7);
        empleadoService.agregarEvaluacionDesempeno(empleado2.getId(), 8);
        empleadoService.agregarEvaluacionDesempeno(empleado2.getId(), 9);
        // Promedio empleado 2: (7 + 8 + 9) / 3 = 8.0
        
        // Verificar promedios individuales
        assertEquals(8.5, empleado1.calcularPromedioDesempeno(), 0.01,
                "El promedio del empleado 1 debe ser 8.5");
        
        assertEquals(8.0, empleado2.calcularPromedioDesempeno(), 0.01,
                "El promedio del empleado 2 debe ser 8.0");
        
        // Verificar promedio departamental
        double promedioDepartamentoEsperado = (8.5 + 8.0) / 2; // 8.25
        assertEquals(promedioDepartamentoEsperado, departamentoTI.calcularPromedioDesempenoDepartamento(), 0.01,
                "El promedio departamental debe ser el promedio de los empleados");
    }
    
    @Test
    @DisplayName("Prueba de validación de evaluaciones de desempeño")
    void testValidacionEvaluacionesDesempeno() {
        Empleado empleado = empleadoService.crearEmpleadoPermanente(
                "Empleado Test", 4000.0, LocalDate.now());
        
        // Prueba de evaluaciones válidas
        assertDoesNotThrow(() -> empleado.agregarEvaluacionDesempeno(5),
                "Debe permitir evaluación válida (5)");
        
        assertDoesNotThrow(() -> empleado.agregarEvaluacionDesempeno(10),
                "Debe permitir evaluación válida (10)");
        
        assertDoesNotThrow(() -> empleado.agregarEvaluacionDesempeno(1),
                "Debe permitir evaluación válida (1)");
        
        // Prueba de evaluaciones inválidas
        assertThrows(IllegalArgumentException.class, () -> empleado.agregarEvaluacionDesempeno(0),
                "No debe permitir evaluación menor a 1");
        
        assertThrows(IllegalArgumentException.class, () -> empleado.agregarEvaluacionDesempeno(11),
                "No debe permitir evaluación mayor a 10");
        
        assertThrows(IllegalArgumentException.class, () -> empleado.agregarEvaluacionDesempeno(-5),
                "No debe permitir evaluación negativa");
    }
    
    @Test
    @DisplayName("Prueba de gestión de contratos temporales")
    void testGestionContratosTemporales() {
        LocalDate fechaInicio = LocalDate.now().minusMonths(3);
        LocalDate fechaFin = LocalDate.now().plusMonths(3);
        
        EmpleadoTemporal empleado = (EmpleadoTemporal) empleadoService.crearEmpleadoTemporal(
                "Empleado Temporal", 4000.0, fechaInicio, fechaFin);
        
        // Verificar estado inicial del contrato
        assertTrue(empleado.isContratoVigente(),
                "El contrato debe estar vigente");
        
        long diasRestantes = empleado.getDiasRestantesContrato();
        assertTrue(diasRestantes > 0 && diasRestantes <= 90,
                "Los días restantes deben estar en el rango esperado");
        
        // Prueba de extensión de contrato
        LocalDate nuevaFechaFin = fechaFin.plusMonths(6);
        assertDoesNotThrow(() -> empleado.extenderContrato(nuevaFechaFin),
                "Debe permitir extender el contrato");
        
        assertEquals(nuevaFechaFin, empleado.getFechaFinContrato(),
                "La fecha de fin debe actualizarse correctamente");
        
        // Prueba de extensión con fecha inválida
        assertThrows(IllegalArgumentException.class, 
                () -> empleado.extenderContrato(fechaFin.minusDays(1)),
                "No debe permitir extender a una fecha anterior");
    }
    
    @Test
    @DisplayName("Prueba de operaciones CRUD de departamentos")
    void testCRUDDepartamentos() {
        // Crear departamento
        Departamento nuevoDepto = departamentoService.crearDepartamento(
                "Finanzas", "Departamento de finanzas y contabilidad");
        
        assertNotNull(nuevoDepto,
                "El departamento debe crearse exitosamente");
        
        assertEquals("Finanzas", nuevoDepto.getNombre(),
                "El nombre debe coincidir");
        
        // Actualizar departamento
        assertTrue(departamentoService.actualizarNombreDepartamento(nuevoDepto.getId(), "Finanzas y Contabilidad"),
                "Debe permitir actualizar el nombre");
        
        var deptoActualizado = departamentoService.obtenerDepartamentoPorId(nuevoDepto.getId());
        assertTrue(deptoActualizado.isPresent(),
                "El departamento debe existir después de actualizar");
        
        assertEquals("Finanzas y Contabilidad", deptoActualizado.get().getNombre(),
                "El nombre debe actualizarse correctamente");
        
        // Eliminar departamento (sin empleados)
        assertTrue(departamentoService.eliminarDepartamento(nuevoDepto.getId()),
                "Debe permitir eliminar departamento sin empleados");
        
        assertFalse(departamentoService.obtenerDepartamentoPorId(nuevoDepto.getId()).isPresent(),
                "El departamento no debe existir después de eliminar");
    }
    
    @Test
    @DisplayName("Prueba de restricción de eliminación de departamentos con empleados")
    void testRestriccionEliminacionDepartamentoConEmpleados() {
        // Crear empleado y asignar a departamento
        Empleado empleado = empleadoService.crearEmpleadoPermanente(
                "Empleado Test", 4000.0, LocalDate.now());
        empleadoService.transferirEmpleado(empleado.getId(), departamentoTI);
        
        // Intentar eliminar departamento con empleados
        assertThrows(IllegalStateException.class, 
                () -> departamentoService.eliminarDepartamento(departamentoTI.getId()),
                "No debe permitir eliminar departamento con empleados asignados");
    }
    
    @Test
    @DisplayName("Prueba de cálculo de estadísticas departamentales")
    void testEstadisticasDepartamentales() {
        // Crear empleados con diferentes salarios
        Empleado emp1 = empleadoService.crearEmpleadoPermanente("Emp1", 5000.0, LocalDate.now());
        Empleado emp2 = empleadoService.crearEmpleadoTemporal("Emp2", 4500.0, 
                LocalDate.now(), LocalDate.now().plusMonths(6));
        Empleado emp3 = empleadoService.crearEmpleadoPermanente("Emp3", 5500.0, LocalDate.now());
        
        // Asignar al departamento
        empleadoService.transferirEmpleado(emp1.getId(), departamentoTI);
        empleadoService.transferirEmpleado(emp2.getId(), departamentoTI);
        empleadoService.transferirEmpleado(emp3.getId(), departamentoTI);
        
        // Verificar estadísticas
        assertEquals(3, departamentoTI.getNumeroEmpleados(),
                "Debe haber 3 empleados en el departamento");
        
        double totalSalariosEsperado = 5000.0 + 4500.0 + 5500.0; // 15000.0
        assertEquals(totalSalariosEsperado, departamentoTI.calcularTotalSalariosDepartamento(), 0.01,
                "El total de salarios debe ser la suma de todos los salarios");
        
        double salarioPromedioEsperado = totalSalariosEsperado / 3; // 5000.0
        assertEquals(salarioPromedioEsperado, totalSalariosEsperado / 3, 0.01,
                "El salario promedio debe calcularse correctamente");
    }
}
