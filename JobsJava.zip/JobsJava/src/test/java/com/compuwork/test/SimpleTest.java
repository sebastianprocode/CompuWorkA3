package com.compuwork.test;

import com.compuwork.model.Empleado;
import com.compuwork.model.EmpleadoPermanente;
import com.compuwork.model.EmpleadoTemporal;
import com.compuwork.model.Departamento;
import com.compuwork.service.EmpleadoService;
import com.compuwork.service.DepartamentoService;

import java.time.LocalDate;

/**
 * Versión simplificada de pruebas para demostración.
 * Validación básica del funcionamiento del sistema CompuWork HR.
 */
public class SimpleTest {
    
    public static void main(String[] args) {
        System.out.println("=== INICIANDO PRUEBAS DEL SISTEMA COMPUWORK ===\n");
        
        // Inicializar servicios
        EmpleadoService empleadoService = new EmpleadoService();
        DepartamentoService departamentoService = new DepartamentoService();
        
        // Crear departamentos
        Departamento deptoTI = departamentoService.crearDepartamento("Tecnología", "Departamento de TI");
        Departamento deptoRRHH = departamentoService.crearDepartamento("Recursos Humanos", "Gestión de personal");
        
        System.out.println("✅ Departamentos creados: " + deptoTI.getNombre() + ", " + deptoRRHH.getNombre());
        
        // Prueba 1: Crear empleado permanente
        LocalDate fechaContratacion = LocalDate.now().minusYears(3);
        EmpleadoPermanente empPermanente = (EmpleadoPermanente) empleadoService.crearEmpleadoPermanente(
                "Juan Pérez", 5000.0, fechaContratacion);
        
        double salarioEsperado = 5000.0 + (5000.0 * 0.05 * 3); // 5750.0
        double salarioCalculado = empPermanente.calcularSalarioTotal();
        
        System.out.println("\n--- PRUEBA 1: Empleado Permanente ---");
        System.out.println("Nombre: " + empPermanente.getNombre());
        System.out.println("Salario Base: $" + empPermanente.getSalarioBase());
        System.out.println("Antigüedad: " + empPermanente.getAntiguedadAnios() + " años");
        System.out.println("Bono Antigüedad: $" + empPermanente.calcularBonoAntiguedad());
        System.out.println("Salario Total Esperado: $" + salarioEsperado);
        System.out.println("Salario Total Calculado: $" + salarioCalculado);
        System.out.println("¿Cálculo correcto? " + (Math.abs(salarioEsperado - salarioCalculado) < 0.01 ? "✅ SÍ" : "❌ NO"));
        System.out.println("¿Tiene beneficios adicionales? " + (empPermanente.tieneBeneficiosAdicionales() ? "✅ SÍ" : "❌ NO"));
        
        // Prueba 2: Crear empleado temporal
        LocalDate fechaInicio = LocalDate.now().minusMonths(6);
        LocalDate fechaFin = LocalDate.now().plusMonths(6);
        EmpleadoTemporal empTemporal = (EmpleadoTemporal) empleadoService.crearEmpleadoTemporal(
                "María García", 4500.0, fechaInicio, fechaFin);
        
        System.out.println("\n--- PRUEBA 2: Empleado Temporal ---");
        System.out.println("Nombre: " + empTemporal.getNombre());
        System.out.println("Salario Base: $" + empTemporal.getSalarioBase());
        System.out.println("Salario Total: $" + empTemporal.calcularSalarioTotal());
        System.out.println("¿Contrato vigente? " + (empTemporal.isContratoVigente() ? "✅ SÍ" : "❌ NO"));
        System.out.println("Días restantes: " + empTemporal.getDiasRestantesContrato());
        System.out.println("¿Salario igual al base? " + (empTemporal.calcularSalarioTotal() == 4500.0 ? "✅ SÍ" : "❌ NO"));
        
        // Prueba 3: Asignación a departamentos
        System.out.println("\n--- PRUEBA 3: Asignación a Departamentos ---");
        
        // Asignar empleados
        empleadoService.transferirEmpleado(empPermanente.getId(), deptoTI);
        empleadoService.transferirEmpleado(empTemporal.getId(), deptoRRHH);
        
        System.out.println("Empleado permanente asignado a: " + 
                (empPermanente.getDepartamento() != null ? empPermanente.getDepartamento().getNombre() : "Sin asignar"));
        System.out.println("Empleado temporal asignado a: " + 
                (empTemporal.getDepartamento() != null ? empTemporal.getDepartamento().getNombre() : "Sin asignar"));
        System.out.println("Empleados en TI: " + deptoTI.getNumeroEmpleados());
        System.out.println("Empleados en RRHH: " + deptoRRHH.getNumeroEmpleados());
        
        // Prueba 4: Evaluaciones de desempeño
        System.out.println("\n--- PRUEBA 4: Evaluaciones de Desempeño ---");
        
        // Agregar evaluaciones
        empPermanente.agregarEvaluacionDesempeno(8);
        empPermanente.agregarEvaluacionDesempeno(9);
        empTemporal.agregarEvaluacionDesempeno(7);
        
        System.out.println("Evaluaciones de " + empPermanente.getNombre() + ": " + empPermanente.getEvaluacionesDesempeno());
        System.out.println("Promedio desempeño: " + empPermanente.calcularPromedioDesempeno());
        System.out.println("Evaluaciones de " + empTemporal.getNombre() + ": " + empTemporal.getEvaluacionesDesempeno());
        System.out.println("Promedio desempeño: " + empTemporal.calcularPromedioDesempeno());
        
        // Prueba 5: Estadísticas departamentales
        System.out.println("\n--- PRUEBA 5: Estadísticas Departamentales ---");
        
        System.out.println("Departamento TI:");
        System.out.println("  - Número empleados: " + deptoTI.getNumeroEmpleados());
        System.out.println("  - Total salarios: $" + deptoTI.calcularTotalSalariosDepartamento());
        System.out.println("  - Promedio desempeño: " + deptoTI.calcularPromedioDesempenoDepartamento());
        
        System.out.println("Departamento RRHH:");
        System.out.println("  - Número empleados: " + deptoRRHH.getNumeroEmpleados());
        System.out.println("  - Total salarios: $" + deptoRRHH.calcularTotalSalariosDepartamento());
        System.out.println("  - Promedio desempeño: " + deptoRRHH.calcularPromedioDesempenoDepartamento());
        
        // Prueba 6: Operaciones CRUD
        System.out.println("\n--- PRUEBA 6: Operaciones CRUD ---");
        
        // Crear nuevo empleado
        Empleado empNuevo = empleadoService.crearEmpleadoPermanente("Carlos López", 5500.0, LocalDate.now());
        System.out.println("Nuevo empleado creado: " + empNuevo.getNombre() + " (ID: " + empNuevo.getId() + ")");
        
        // Buscar empleado
        var encontrado = empleadoService.obtenerEmpleadoPorId(empNuevo.getId());
        System.out.println("¿Empleado encontrado por ID? " + (encontrado.isPresent() ? "✅ SÍ" : "❌ NO"));
        
        // Actualizar nombre
        boolean actualizado = empleadoService.actualizarNombreEmpleado(empNuevo.getId(), "Carlos López Modificado");
        System.out.println("¿Nombre actualizado? " + (actualizado ? "✅ SÍ" : "❌ NO"));
        
        // Eliminar empleado
        boolean eliminado = empleadoService.eliminarEmpleado(empNuevo.getId());
        System.out.println("¿Empleado eliminado? " + (eliminado ? "✅ SÍ" : "❌ NO"));
        
        var verificacion = empleadoService.obtenerEmpleadoPorId(empNuevo.getId());
        System.out.println("¿Empleado aún existe? " + (verificacion.isPresent() ? "❌ SÍ (error)" : "✅ NO (correcto)"));
        
        // Resumen final
        System.out.println("\n=== RESUMEN FINAL ===");
        System.out.println("Total empleados creados: " + empleadoService.getTotalEmpleados());
        System.out.println("Total departamentos creados: " + departamentoService.getTotalDepartamentos());
        System.out.println("Total empleados en TI: " + deptoTI.getNumeroEmpleados());
        System.out.println("Total empleados en RRHH: " + deptoRRHH.getNumeroEmpleados());
        
        System.out.println("\n🎉 ¡PRUEBAS COMPLETADAS CON ÉXITO!");
        System.out.println("📊 El sistema CompuWork HR funciona correctamente.");
        System.out.println("🖥️  La interfaz gráfica está lista para usar.");
    }
}
