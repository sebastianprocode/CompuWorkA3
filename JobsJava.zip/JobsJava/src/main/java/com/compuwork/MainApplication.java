package com.compuwork;

import com.compuwork.view.CompuWorkMainFrame;

/**
 * Clase principal para iniciar la aplicación CompuWork HR System.
 * Punto de entrada principal del sistema de gestión de recursos humanos.
 * 
 * @author CompuWork Team
 * @version 1.0.0
 */
public class MainApplication {
    
    /**
     * Método principal que inicia la aplicación.
     * @param args Argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        // Iniciar la interfaz gráfica en el Event Dispatch Thread
        javax.swing.SwingUtilities.invokeLater(() -> {
            try {
                // Configurar Look and Feel del sistema
                javax.swing.UIManager.setLookAndFeel(
                    javax.swing.UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Error al configurar Look and Feel: " + e.getMessage());
            }
            
            // Crear y mostrar la ventana principal
            new CompuWorkMainFrame().setVisible(true);
        });
    }
}
