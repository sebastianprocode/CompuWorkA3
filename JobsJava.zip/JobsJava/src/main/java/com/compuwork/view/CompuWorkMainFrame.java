package com.compuwork.view;

import com.compuwork.service.EmpleadoService;
import com.compuwork.service.DepartamentoService;
import com.compuwork.service.ReporteDesempenoService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Interfaz gráfica principal del sistema CompuWork HR.
 * Proporciona una GUI intuitiva para la gestión de empleados y visualización de reportes.
 * 
 * Principio SOLID: Interface Segregation - La interfaz está dividida en paneles 
 * especializados para cada funcionalidad específica.
 */
public class CompuWorkMainFrame extends JFrame {
    private final EmpleadoService empleadoService;
    private final DepartamentoService departamentoService;
    private final ReporteDesempenoService reporteService;
    
    // Componentes de la interfaz
    private JTabbedPane tabbedPane;
    private JPanel panelEmpleados, panelDepartamentos, panelReportes;
    
    // Componentes de empleados
    private JTextField txtNombreEmpleado, txtSalarioBase, txtFechaContratacion, txtFechaFinContrato;
    private JComboBox<String> cmbTipoEmpleado, cmbDepartamentoEmpleado;
    private JTable tablaEmpleados;
    private DefaultTableModel modeloTablaEmpleados;
    private JPanel panelBotonesEmpleados;
    
    // Componentes de departamentos
    private JTextField txtNombreDepartamento;
    private JTextArea txtDescripcionDepartamento;
    private JTable tablaDepartamentos;
    private DefaultTableModel modeloTablaDepartamentos;
    private JPanel panelBotonesDepartamentos;
    
    // Componentes de reportes
    private JComboBox<String> cmbTipoReporte, cmbSeleccionReporte;
    private JTextArea txtAreaReportes;
    private JPanel panelBotonesReportes;
    
    /**
     * Constructor de la ventana principal.
     * Inicializa los servicios y la interfaz gráfica.
     */
    public CompuWorkMainFrame() {
        // Inicializar servicios
        this.empleadoService = new EmpleadoService();
        this.departamentoService = new DepartamentoService();
        this.reporteService = new ReporteDesempenoService(empleadoService, departamentoService);
        
        // Configurar ventana principal
        setTitle("CompuWork - Sistema de Gestión de Recursos Humanos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Inicializar componentes
        inicializarComponentes();
        configurarLayout();
        configurarEventos();
        
        // Cargar datos iniciales
        cargarDatosIniciales();
        actualizarTablas();
    }
    
    /**
     * Inicializa todos los componentes de la interfaz.
     */
    private void inicializarComponentes() {
        // Panel principal con pestañas
        tabbedPane = new JTabbedPane();
        
        // Inicializar panel de empleados
        panelEmpleados = new JPanel(new BorderLayout());
        configurarPanelEmpleados();
        
        // Inicializar panel de departamentos
        panelDepartamentos = new JPanel(new BorderLayout());
        configurarPanelDepartamentos();
        
        // Inicializar panel de reportes
        panelReportes = new JPanel(new BorderLayout());
        configurarPanelReportes();
        
        // Agregar paneles al tabbedPane
        tabbedPane.addTab("Gestión de Empleados", panelEmpleados);
        tabbedPane.addTab("Gestión de Departamentos", panelDepartamentos);
        tabbedPane.addTab("Reportes de Desempeño", panelReportes);
    }
    
    /**
     * Configura el panel de gestión de empleados.
     */
    private void configurarPanelEmpleados() {
        // Panel de formulario
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBorder(new EmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Campos del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        txtNombreEmpleado = new JTextField(20);
        panelFormulario.add(txtNombreEmpleado, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Salario Base:"), gbc);
        gbc.gridx = 1;
        txtSalarioBase = new JTextField(20);
        panelFormulario.add(txtSalarioBase, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panelFormulario.add(new JLabel("Fecha Contratación:"), gbc);
        gbc.gridx = 1;
        txtFechaContratacion = new JTextField(20);
        txtFechaContratacion.setText(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        panelFormulario.add(txtFechaContratacion, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panelFormulario.add(new JLabel("Tipo Empleado:"), gbc);
        gbc.gridx = 1;
        cmbTipoEmpleado = new JComboBox<>(new String[]{"Permanente", "Temporal"});
        panelFormulario.add(cmbTipoEmpleado, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        panelFormulario.add(new JLabel("Fecha Fin Contrato:"), gbc);
        gbc.gridx = 1;
        txtFechaFinContrato = new JTextField(20);
        txtFechaFinContrato.setEnabled(false);
        panelFormulario.add(txtFechaFinContrato, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5;
        panelFormulario.add(new JLabel("Departamento:"), gbc);
        gbc.gridx = 1;
        cmbDepartamentoEmpleado = new JComboBox<>();
        panelFormulario.add(cmbDepartamentoEmpleado, gbc);
        
        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnAgregarEmpleado = new JButton("Agregar Empleado");
        JButton btnActualizarEmpleado = new JButton("Actualizar Empleado");
        JButton btnEliminarEmpleado = new JButton("Eliminar Empleado");
        JButton btnLimpiarFormulario = new JButton("Limpiar Formulario");
        
        panelBotones.add(btnAgregarEmpleado);
        panelBotones.add(btnActualizarEmpleado);
        panelBotones.add(btnEliminarEmpleado);
        panelBotones.add(btnLimpiarFormulario);
        
        // Guardar referencia al panel de botones para eventos
        panelBotonesEmpleados = panelBotones;
        
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        panelFormulario.add(panelBotones, gbc);
        
        // Tabla de empleados
        modeloTablaEmpleados = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Tipo", "Salario", "Departamento", "Desempeño"}, 0);
        tablaEmpleados = new JTable(modeloTablaEmpleados);
        JScrollPane scrollPaneEmpleados = new JScrollPane(tablaEmpleados);
        
        // Agregar componentes al panel
        panelEmpleados.add(panelFormulario, BorderLayout.NORTH);
        panelEmpleados.add(scrollPaneEmpleados, BorderLayout.CENTER);
    }
    
    /**
     * Configura el panel de gestión de departamentos.
     */
    private void configurarPanelDepartamentos() {
        // Panel de formulario
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBorder(new EmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Nombre Departamento:"), gbc);
        gbc.gridx = 1;
        txtNombreDepartamento = new JTextField(20);
        panelFormulario.add(txtNombreDepartamento, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Descripción:"), gbc);
        gbc.gridx = 1;
        txtDescripcionDepartamento = new JTextArea(3, 20);
        txtDescripcionDepartamento.setLineWrap(true);
        JScrollPane scrollDescripcion = new JScrollPane(txtDescripcionDepartamento);
        panelFormulario.add(scrollDescripcion, gbc);
        
        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnAgregarDepartamento = new JButton("Agregar Departamento");
        JButton btnActualizarDepartamento = new JButton("Actualizar Departamento");
        JButton btnEliminarDepartamento = new JButton("Eliminar Departamento");
        JButton btnLimpiarDepartamento = new JButton("Limpiar Formulario");
        
        panelBotones.add(btnAgregarDepartamento);
        panelBotones.add(btnActualizarDepartamento);
        panelBotones.add(btnEliminarDepartamento);
        panelBotones.add(btnLimpiarDepartamento);
        
        // Guardar referencia al panel de botones para eventos
        panelBotonesDepartamentos = panelBotones;
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        panelFormulario.add(panelBotones, gbc);
        
        // Tabla de departamentos
        modeloTablaDepartamentos = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Descripción", "Empleados", "Promedio Desempeño"}, 0);
        tablaDepartamentos = new JTable(modeloTablaDepartamentos);
        JScrollPane scrollPaneDepartamentos = new JScrollPane(tablaDepartamentos);
        
        // Agregar componentes al panel
        panelDepartamentos.add(panelFormulario, BorderLayout.NORTH);
        panelDepartamentos.add(scrollPaneDepartamentos, BorderLayout.CENTER);
    }
    
    /**
     * Configura el panel de reportes.
     */
    private void configurarPanelReportes() {
        // Panel de configuración de reportes
        JPanel panelConfiguracion = new JPanel(new FlowLayout());
        panelConfiguracion.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        panelConfiguracion.add(new JLabel("Tipo de Reporte:"));
        cmbTipoReporte = new JComboBox<>(new String[]{"Individual", "Departamental", "General"});
        panelConfiguracion.add(cmbTipoReporte);
        
        panelConfiguracion.add(new JLabel("Seleccionar:"));
        cmbSeleccionReporte = new JComboBox<>();
        panelConfiguracion.add(cmbSeleccionReporte);
        
        JButton btnGenerarReporte = new JButton("Generar Reporte");
        panelConfiguracion.add(btnGenerarReporte);
        
        JButton btnActualizarReportes = new JButton("Actualizar Listas");
        panelConfiguracion.add(btnActualizarReportes);
        
        // Guardar referencia al panel de botones para eventos
        panelBotonesReportes = panelConfiguracion;
        
        // Área de reportes
        txtAreaReportes = new JTextArea();
        txtAreaReportes.setEditable(false);
        txtAreaReportes.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPaneReportes = new JScrollPane(txtAreaReportes);
        
        // Agregar componentes al panel
        panelReportes.add(panelConfiguracion, BorderLayout.NORTH);
        panelReportes.add(scrollPaneReportes, BorderLayout.CENTER);
    }
    
    /**
     * Configura el layout principal de la ventana.
     */
    private void configurarLayout() {
        add(tabbedPane);
    }
    
    /**
     * Configura los eventos de los componentes.
     */
    private void configurarEventos() {
        // Evento de cambio en tipo de empleado
        cmbTipoEmpleado.addActionListener(e -> {
            String tipo = (String) cmbTipoEmpleado.getSelectedItem();
            txtFechaFinContrato.setEnabled("Temporal".equals(tipo));
        });
        
        // Evento de cambio en tipo de reporte
        cmbTipoReporte.addActionListener(e -> actualizarSeleccionReportes());
        
        // Configurar eventos de botones de empleados
        configurarEventosBotonesEmpleados();
        
        // Configurar eventos de botones de departamentos
        configurarEventosBotonesDepartamentos();
        
        // Configurar eventos de botones de reportes
        configurarEventosBotonesReportes();
    }
    
    /**
     * Configura los eventos de los botones del panel de empleados.
     */
    private void configurarEventosBotonesEmpleados() {
        if (panelBotonesEmpleados != null) {
            for (Component comp : panelBotonesEmpleados.getComponents()) {
                if (comp instanceof JButton) {
                    JButton btn = (JButton) comp;
                    btn.addActionListener(e -> manejarEventoBotonEmpleado(btn.getText()));
                }
            }
        }
    }
    
    /**
     * Configura los eventos de los botones del panel de departamentos.
     */
    private void configurarEventosBotonesDepartamentos() {
        if (panelBotonesDepartamentos != null) {
            for (Component comp : panelBotonesDepartamentos.getComponents()) {
                if (comp instanceof JButton) {
                    JButton btn = (JButton) comp;
                    btn.addActionListener(e -> manejarEventoBotonDepartamento(btn.getText()));
                }
            }
        }
    }
    
    /**
     * Configura los eventos de los botones del panel de reportes.
     */
    private void configurarEventosBotonesReportes() {
        if (panelBotonesReportes != null) {
            for (Component comp : panelBotonesReportes.getComponents()) {
                if (comp instanceof JButton) {
                    JButton btn = (JButton) comp;
                    btn.addActionListener(e -> manejarEventoBotonReporte(btn.getText()));
                }
            }
        }
    }
    
    /**
     * Encuentra el panel de botones dentro de un panel contenedor.
     */
    private JPanel encontrarBotonesPanel(JPanel contenedor) {
        for (Component comp : contenedor.getComponents()) {
            if (comp instanceof JPanel) {
                JPanel panel = (JPanel) comp;
                // Verificar si este panel contiene botones
                boolean tieneBotones = false;
                for (Component innerComp : panel.getComponents()) {
                    if (innerComp instanceof JButton) {
                        tieneBotones = true;
                        break;
                    }
                }
                if (tieneBotones) {
                    return panel;
                }
            }
        }
        return null;
    }
    
    /**
     * Maneja los eventos de los botones de empleados.
     */
    private void manejarEventoBotonEmpleado(String accion) {
        try {
            switch (accion) {
                case "Agregar Empleado":
                    agregarEmpleado();
                    break;
                case "Actualizar Empleado":
                    actualizarEmpleado();
                    break;
                case "Eliminar Empleado":
                    eliminarEmpleado();
                    break;
                case "Limpiar Formulario":
                    limpiarFormularioEmpleado();
                    break;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Maneja los eventos de los botones de departamentos.
     */
    private void manejarEventoBotonDepartamento(String accion) {
        try {
            switch (accion) {
                case "Agregar Departamento":
                    agregarDepartamento();
                    break;
                case "Actualizar Departamento":
                    actualizarDepartamento();
                    break;
                case "Eliminar Departamento":
                    eliminarDepartamento();
                    break;
                case "Limpiar Formulario":
                    limpiarFormularioDepartamento();
                    break;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Maneja los eventos de los botones de reportes.
     */
    private void manejarEventoBotonReporte(String accion) {
        try {
            switch (accion) {
                case "Generar Reporte":
                    generarReporte();
                    break;
                case "Actualizar Listas":
                    actualizarSeleccionReportes();
                    actualizarTablas();
                    break;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Agrega un nuevo empleado.
     */
    private void agregarEmpleado() {
        String nombre = txtNombreEmpleado.getText().trim();
        String salarioStr = txtSalarioBase.getText().trim();
        String fechaStr = txtFechaContratacion.getText().trim();
        String tipo = (String) cmbTipoEmpleado.getSelectedItem();
        
        if (nombre.isEmpty() || salarioStr.isEmpty() || fechaStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Complete todos los campos obligatorios", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            double salario = Double.parseDouble(salarioStr);
            LocalDate fechaContratacion = LocalDate.parse(fechaStr);
            
            com.compuwork.model.Empleado empleado;
            if ("Permanente".equals(tipo)) {
                empleado = empleadoService.crearEmpleadoPermanente(nombre, salario, fechaContratacion);
            } else {
                String fechaFinStr = txtFechaFinContrato.getText().trim();
                if (fechaFinStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, 
                        "Ingrese la fecha de fin de contrato", 
                        "Validación", 
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
                LocalDate fechaFin = LocalDate.parse(fechaFinStr);
                empleado = empleadoService.crearEmpleadoTemporal(nombre, salario, fechaContratacion, fechaFin);
            }
            
            // Asignar a departamento si se seleccionó uno
            if (cmbDepartamentoEmpleado.getSelectedIndex() > 0) {
                String deptoSeleccionado = (String) cmbDepartamentoEmpleado.getSelectedItem();
                int deptoId = Integer.parseInt(deptoSeleccionado.split(" - ")[0]);
                var depto = departamentoService.obtenerDepartamentoPorId(deptoId);
                if (depto.isPresent()) {
                    empleadoService.transferirEmpleado(empleado.getId(), depto.get());
                }
            }
            
            actualizarTablas();
            limpiarFormularioEmpleado();
            
            JOptionPane.showMessageDialog(this, 
                "Empleado agregado exitosamente", 
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "El salario debe ser un número válido", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error al agregar empleado: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Actualiza un empleado existente.
     */
    private void actualizarEmpleado() {
        int filaSeleccionada = tablaEmpleados.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, 
                "Seleccione un empleado de la tabla para actualizar", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int empleadoId = (int) modeloTablaEmpleados.getValueAt(filaSeleccionada, 0);
            var empleadoOpt = empleadoService.obtenerEmpleadoPorId(empleadoId);
            
            if (empleadoOpt.isPresent()) {
                String nombre = txtNombreEmpleado.getText().trim();
                String salarioStr = txtSalarioBase.getText().trim();
                
                if (nombre.isEmpty() || salarioStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, 
                        "Complete todos los campos obligatorios", 
                        "Validación", 
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                double salario = Double.parseDouble(salarioStr);
                
                empleadoService.actualizarNombreEmpleado(empleadoId, nombre);
                empleadoService.actualizarSalarioEmpleado(empleadoId, salario);
                
                actualizarTablas();
                limpiarFormularioEmpleado();
                
                JOptionPane.showMessageDialog(this, 
                    "Empleado actualizado exitosamente", 
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "El salario debe ser un número válido", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error al actualizar empleado: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Elimina un empleado existente.
     */
    private void eliminarEmpleado() {
        int filaSeleccionada = tablaEmpleados.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, 
                "Seleccione un empleado de la tabla para eliminar", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar este empleado?", 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                int empleadoId = (int) modeloTablaEmpleados.getValueAt(filaSeleccionada, 0);
                boolean eliminado = empleadoService.eliminarEmpleado(empleadoId);
                
                if (eliminado) {
                    actualizarTablas();
                    limpiarFormularioEmpleado();
                    
                    JOptionPane.showMessageDialog(this, 
                        "Empleado eliminado exitosamente", 
                        "Éxito", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "No se pudo eliminar el empleado", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                    "Error al eliminar empleado: " + e.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Limpia el formulario de empleados.
     */
    private void limpiarFormularioEmpleado() {
        txtNombreEmpleado.setText("");
        txtSalarioBase.setText("");
        txtFechaContratacion.setText(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        txtFechaFinContrato.setText("");
        txtFechaFinContrato.setEnabled(false);
        cmbTipoEmpleado.setSelectedIndex(0);
        cmbDepartamentoEmpleado.setSelectedIndex(0);
    }
    
    /**
     * Agrega un nuevo departamento.
     */
    private void agregarDepartamento() {
        String nombre = txtNombreDepartamento.getText().trim();
        String descripcion = txtDescripcionDepartamento.getText().trim();
        
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Ingrese el nombre del departamento", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            departamentoService.crearDepartamento(nombre, descripcion);
            
            actualizarTablas();
            limpiarFormularioDepartamento();
            
            JOptionPane.showMessageDialog(this, 
                "Departamento agregado exitosamente", 
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error al agregar departamento: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Actualiza un departamento existente.
     */
    private void actualizarDepartamento() {
        int filaSeleccionada = tablaDepartamentos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, 
                "Seleccione un departamento de la tabla para actualizar", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int deptoId = (int) modeloTablaDepartamentos.getValueAt(filaSeleccionada, 0);
            var deptoOpt = departamentoService.obtenerDepartamentoPorId(deptoId);
            
            if (deptoOpt.isPresent()) {
                String nombre = txtNombreDepartamento.getText().trim();
                String descripcion = txtDescripcionDepartamento.getText().trim();
                
                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(this, 
                        "Ingrese el nombre del departamento", 
                        "Validación", 
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                departamentoService.actualizarNombreDepartamento(deptoId, nombre);
                departamentoService.actualizarDescripcionDepartamento(deptoId, descripcion);
                
                actualizarTablas();
                limpiarFormularioDepartamento();
                
                JOptionPane.showMessageDialog(this, 
                    "Departamento actualizado exitosamente", 
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error al actualizar departamento: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Elimina un departamento existente.
     */
    private void eliminarDepartamento() {
        int filaSeleccionada = tablaDepartamentos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, 
                "Seleccione un departamento de la tabla para eliminar", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de eliminar este departamento?", 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                int deptoId = (int) modeloTablaDepartamentos.getValueAt(filaSeleccionada, 0);
                boolean eliminado = departamentoService.eliminarDepartamento(deptoId);
                
                if (eliminado) {
                    actualizarTablas();
                    limpiarFormularioDepartamento();
                    
                    JOptionPane.showMessageDialog(this, 
                        "Departamento eliminado exitosamente", 
                        "Éxito", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "No se pudo eliminar el departamento. Puede que tenga empleados asignados.", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                    "Error al eliminar departamento: " + e.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Limpia el formulario de departamentos.
     */
    private void limpiarFormularioDepartamento() {
        txtNombreDepartamento.setText("");
        txtDescripcionDepartamento.setText("");
    }
    
    /**
     * Genera y muestra un reporte.
     */
    private void generarReporte() {
        String tipoReporte = (String) cmbTipoReporte.getSelectedItem();
        String seleccion = (String) cmbSeleccionReporte.getSelectedItem();
        
        if (seleccion == null || seleccion.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Seleccione un elemento para generar el reporte", 
                "Validación", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            StringBuilder reporte = new StringBuilder();
            
            switch (tipoReporte) {
                case "Individual":
                    int empleadoId = Integer.parseInt(seleccion.split(" - ")[0]);
                    var reporteIndividual = reporteService.generarReporteIndividual(empleadoId);
                    reporte.append("=== REPORTE INDIVIDUAL ===\n\n");
                    reporte.append("ID: ").append(reporteIndividual.empleadoId).append("\n");
                    reporte.append("Nombre: ").append(reporteIndividual.nombre).append("\n");
                    reporte.append("Tipo: ").append(reporteIndividual.tipo).append("\n");
                    reporte.append("Departamento: ").append(reporteIndividual.departamento).append("\n");
                    reporte.append("Salario Total: $").append(String.format("%.2f", reporteIndividual.salarioTotal)).append("\n");
                    reporte.append("Antigüedad: ").append(reporteIndividual.antiguedadAnios).append(" años\n");
                    reporte.append("Evaluaciones: ").append(reporteIndividual.totalEvaluaciones).append("\n");
                    reporte.append("Promedio Desempeño: ").append(String.format("%.2f", reporteIndividual.promedioDesempeno)).append("\n");
                    break;
                    
                case "Departamental":
                    int deptoId = Integer.parseInt(seleccion.split(" - ")[0]);
                    var reporteDepto = reporteService.generarReporteDepartamental(deptoId);
                    reporte.append("=== REPORTE DEPARTAMENTAL ===\n\n");
                    reporte.append("Departamento: ").append(reporteDepto.nombreDepartamento).append("\n");
                    reporte.append("Total Empleados: ").append(reporteDepto.totalEmpleados).append("\n");
                    reporte.append("Empleados Permanentes: ").append(reporteDepto.empleadosPermanentes).append("\n");
                    reporte.append("Empleados Temporales: ").append(reporteDepto.totalEmpleados - reporteDepto.empleadosPermanentes).append("\n");
                    reporte.append("Total Salarios: $").append(String.format("%.2f", reporteDepto.totalSalarios)).append("\n");
                    reporte.append("Salario Promedio: $").append(String.format("%.2f", reporteDepto.salarioPromedio)).append("\n");
                    reporte.append("Promedio Desempeño: ").append(String.format("%.2f", reporteDepto.promedioDesempeno)).append("\n\n");
                    reporte.append("=== DETALLE DE EMPLEADOS ===\n");
                    for (var emp : reporteDepto.empleados) {
                        reporte.append("- ").append(emp.toString()).append("\n");
                    }
                    break;
                    
                case "General":
                    var reporteGeneral = reporteService.generarReporteGeneral();
                    reporte.append(reporteGeneral.toString()).append("\n\n");
                    reporte.append("=== TOP 5 EMPLEADOS ===\n");
                    for (var emp : reporteGeneral.topEmpleados) {
                        reporte.append("- ").append(emp.toString()).append("\n");
                    }
                    break;
            }
            
            txtAreaReportes.setText(reporte.toString());
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error al generar reporte: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Carga datos iniciales de demostración.
     */
    private void cargarDatosIniciales() {
        // Crear departamentos de ejemplo
        var deptoTI = departamentoService.crearDepartamento("Tecnología", "Departamento de TI y desarrollo");
        var deptoRRHH = departamentoService.crearDepartamento("Recursos Humanos", "Gestión de personal");
        var deptoVentas = departamentoService.crearDepartamento("Ventas", "Equipo de ventas y marketing");
        
        // Crear empleados de ejemplo
        var emp1 = empleadoService.crearEmpleadoPermanente("Juan Pérez", 5000.0, 
                LocalDate.of(2020, 1, 15));
        var emp2 = empleadoService.crearEmpleadoTemporal("María García", 4500.0, 
                LocalDate.of(2023, 6, 1), LocalDate.of(2024, 6, 1));
        var emp3 = empleadoService.crearEmpleadoPermanente("Carlos López", 5500.0, 
                LocalDate.of(2019, 3, 10));
        
        // Asignar departamentos
        empleadoService.transferirEmpleado(emp1.getId(), deptoTI);
        empleadoService.transferirEmpleado(emp2.getId(), deptoRRHH);
        empleadoService.transferirEmpleado(emp3.getId(), deptoVentas);
        
        // Agregar evaluaciones de desempeño
        empleadoService.agregarEvaluacionDesempeno(emp1.getId(), 8);
        empleadoService.agregarEvaluacionDesempeno(emp1.getId(), 9);
        empleadoService.agregarEvaluacionDesempeno(emp2.getId(), 7);
        empleadoService.agregarEvaluacionDesempeno(emp3.getId(), 9);
        empleadoService.agregarEvaluacionDesempeno(emp3.getId(), 10);
    }
    
    /**
     * Actualiza las tablas con los datos actuales.
     */
    private void actualizarTablas() {
        actualizarTablaEmpleados();
        actualizarTablaDepartamentos();
        actualizarSeleccionReportes();
        actualizarComboDepartamentos();
    }
    
    /**
     * Actualiza el combo de departamentos para asignación de empleados.
     */
    private void actualizarComboDepartamentos() {
        cmbDepartamentoEmpleado.removeAllItems();
        cmbDepartamentoEmpleado.addItem("Sin asignar");
        
        var departamentos = departamentoService.obtenerTodosLosDepartamentos();
        for (var depto : departamentos) {
            cmbDepartamentoEmpleado.addItem(depto.getId() + " - " + depto.getNombre());
        }
    }
    
    /**
     * Actualiza la tabla de empleados.
     */
    private void actualizarTablaEmpleados() {
        modeloTablaEmpleados.setRowCount(0);
        var empleados = empleadoService.obtenerTodosLosEmpleados();
        
        for (var empleado : empleados) {
            String tipo = empleado instanceof com.compuwork.model.EmpleadoPermanente ? "Permanente" : "Temporal";
            String departamento = empleado.getDepartamento() != null ? 
                    empleado.getDepartamento().getNombre() : "Sin asignar";
            double desempeño = empleado.calcularPromedioDesempeno();
            
            modeloTablaEmpleados.addRow(new Object[]{
                empleado.getId(),
                empleado.getNombre(),
                tipo,
                String.format("$%.2f", empleado.calcularSalarioTotal()),
                departamento,
                desempeño > 0 ? String.format("%.2f", desempeño) : "Sin evaluación"
            });
        }
    }
    
    /**
     * Actualiza la tabla de departamentos.
     */
    private void actualizarTablaDepartamentos() {
        modeloTablaDepartamentos.setRowCount(0);
        var departamentos = departamentoService.obtenerTodosLosDepartamentos();
        
        for (var departamento : departamentos) {
            modeloTablaDepartamentos.addRow(new Object[]{
                departamento.getId(),
                departamento.getNombre(),
                departamento.getDescripcion(),
                departamento.getNumeroEmpleados(),
                departamento.calcularPromedioDesempenoDepartamento() > 0 ? 
                    String.format("%.2f", departamento.calcularPromedioDesempenoDepartamento()) : 
                    "Sin evaluaciones"
            });
        }
    }
    
    /**
     * Actualiza las opciones del combo de selección de reportes.
     */
    private void actualizarSeleccionReportes() {
        cmbSeleccionReporte.removeAllItems();
        String tipoReporte = (String) cmbTipoReporte.getSelectedItem();
        
        switch (tipoReporte) {
            case "Individual":
                var empleados = empleadoService.obtenerTodosLosEmpleados();
                for (var emp : empleados) {
                    cmbSeleccionReporte.addItem(emp.getId() + " - " + emp.getNombre());
                }
                break;
            case "Departamental":
                var departamentos = departamentoService.obtenerTodosLosDepartamentos();
                for (var dept : departamentos) {
                    cmbSeleccionReporte.addItem(dept.getId() + " - " + dept.getNombre());
                }
                break;
            case "General":
                cmbSeleccionReporte.addItem("Reporte General de la Empresa");
                break;
        }
    }
    
    /**
     * Método principal para iniciar la aplicación.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            CompuWorkMainFrame frame = new CompuWorkMainFrame();
            frame.setVisible(true);
        });
    }
}
