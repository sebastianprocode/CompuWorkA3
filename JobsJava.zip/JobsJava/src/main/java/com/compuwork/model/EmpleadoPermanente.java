package com.compuwork.model;

import java.time.LocalDate;

/**
 * Clase que representa un empleado permanente con contrato indefinido.
 * Hereda de Empleado y añade la lógica de bono por antigüedad.
 * 
 * Principio SOLID: Open/Closed - La clase está abierta para extensión 
 * pero cerrada para modificación mediante herencia.
 */
public class EmpleadoPermanente extends Empleado {
    private static final double BONO_POR_ANIO = 0.05; // 5% de bono por año de antigüedad
    
    /**
     * Constructor de EmpleadoPermanente.
     * @param id Identificador único del empleado
     * @param nombre Nombre completo del empleado
     * @param salarioBase Salario base mensual
     * @param fechaContratacion Fecha de inicio del contrato
     */
    public EmpleadoPermanente(int id, String nombre, double salarioBase, LocalDate fechaContratacion) {
        super(id, nombre, salarioBase, fechaContratacion);
    }
    
    /**
     * Calcula el salario total incluyendo el bono por antigüedad.
     * El bono es del 5% por cada año de antigüedad.
     * @return Salario total con bono incluido
     */
    @Override
    public double calcularSalarioTotal() {
        double salarioBase = getSalarioBase();
        int antiguedad = getAntiguedadAnios();
        double bonoAntiguedad = salarioBase * (BONO_POR_ANIO * antiguedad);
        
        return salarioBase + bonoAntiguedad;
    }
    
    /**
     * Calcula el bono por antigüedad.
     * @return Monto del bono por antigüedad
     */
    public double calcularBonoAntiguedad() {
        return getSalarioBase() * (BONO_POR_ANIO * getAntiguedadAnios());
    }
    
    /**
     * Verifica si el empleado es elegible para beneficios adicionales.
     * Los empleados permanentes con más de 2 años tienen beneficios adicionales.
     * @return true si es elegible para beneficios adicionales
     */
    public boolean tieneBeneficiosAdicionales() {
        return getAntiguedadAnios() >= 2;
    }
    
    @Override
    public String toString() {
        return String.format("EmpleadoPermanente{id=%d, nombre='%s', salarioBase=%.2f, " +
                           "salarioTotal=%.2f, antiguedad=%d años, bono=%.2f}", 
                           getId(), getNombre(), getSalarioBase(), 
                           calcularSalarioTotal(), getAntiguedadAnios(), calcularBonoAntiguedad());
    }
}
