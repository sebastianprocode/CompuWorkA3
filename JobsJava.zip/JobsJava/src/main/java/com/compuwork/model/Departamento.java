package com.compuwork.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Clase que representa un departamento de la organización.
 * Gestiona una lista de empleados y proporciona métodos para su administración.
 * 
 * Principio SOLID: Single Responsibility - Esta clase solo se encarga de 
 * gestionar los empleados de un departamento específico.
 */
public class Departamento {
    private int id;
    private String nombre;
    private String descripcion;
    private List<Empleado> empleados;
    
    /**
     * Constructor de la clase Departamento.
     * @param id Identificador único del departamento
     * @param nombre Nombre del departamento
     * @param descripcion Descripción del departamento
     */
    public Departamento(int id, String nombre, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.empleados = new ArrayList<>();
    }
    
    /**
     * Agrega un empleado al departamento.
     * @param empleado Empleado a agregar
     * @return true si se agregó exitosamente, false si ya existía
     */
    public boolean agregarEmpleado(Empleado empleado) {
        if (empleado == null) {
            throw new IllegalArgumentException("El empleado no puede ser nulo");
        }
        
        if (empleados.contains(empleado)) {
            return false;
        }
        
        empleados.add(empleado);
        empleado.setDepartamento(this);
        return true;
    }
    
    /**
     * Elimina un empleado del departamento.
     * @param empleado Empleado a eliminar
     * @return true si se eliminó exitosamente, false si no existía
     */
    public boolean eliminarEmpleado(Empleado empleado) {
        if (empleado == null) {
            return false;
        }
        
        boolean eliminado = empleados.remove(empleado);
        if (eliminado) {
            empleado.setDepartamento(null);
        }
        return eliminado;
    }
    
    /**
     * Elimina un empleado del departamento por su ID.
     * @param empleadoId ID del empleado a eliminar
     * @return true si se eliminó exitosamente, false si no existía
     */
    public boolean eliminarEmpleadoPorId(int empleadoId) {
        Optional<Empleado> empleadoOpt = buscarEmpleadoPorId(empleadoId);
        if (empleadoOpt.isPresent()) {
            return eliminarEmpleado(empleadoOpt.get());
        }
        return false;
    }
    
    /**
     * Busca un empleado por su ID.
     * @param empleadoId ID del empleado a buscar
     * @return Optional con el empleado encontrado o vacío si no existe
     */
    public Optional<Empleado> buscarEmpleadoPorId(int empleadoId) {
        return empleados.stream()
                .filter(emp -> emp.getId() == empleadoId)
                .findFirst();
    }
    
    /**
     * Busca empleados por su nombre (búsqueda parcial).
     * @param nombre Nombre o parte del nombre a buscar
     * @return Lista de empleados que coinciden con la búsqueda
     */
    public List<Empleado> buscarEmpleadosPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return new ArrayList<>();
        }
        
        String nombreBusqueda = nombre.toLowerCase().trim();
        return empleados.stream()
                .filter(emp -> emp.getNombre().toLowerCase().contains(nombreBusqueda))
                .toList();
    }
    
    /**
     * Obtiene el número total de empleados en el departamento.
     * @return Cantidad de empleados
     */
    public int getNumeroEmpleados() {
        return empleados.size();
    }
    
    /**
     * Calcula el promedio de desempeño del departamento.
     * @return Promedio de desempeño de todos los empleados del departamento
     */
    public double calcularPromedioDesempenoDepartamento() {
        if (empleados.isEmpty()) {
            return 0.0;
        }
        
        return empleados.stream()
                .mapToDouble(Empleado::calcularPromedioDesempeno)
                .average()
                .orElse(0.0);
    }
    
    /**
     * Calcula el total de salarios del departamento.
     * @return Suma de todos los salarios de los empleados
     */
    public double calcularTotalSalariosDepartamento() {
        return empleados.stream()
                .mapToDouble(Empleado::calcularSalarioTotal)
                .sum();
    }
    
    /**
     * Obtiene una copia de la lista de empleados.
     * @return Lista inmutable de empleados
     */
    public List<Empleado> getEmpleados() {
        return new ArrayList<>(empleados);
    }
    
    /**
     * Verifica si el departamento tiene empleados asignados.
     * @return true si hay empleados, false si está vacío
     */
    public boolean tieneEmpleados() {
        return !empleados.isEmpty();
    }
    
    // Getters y Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    @Override
    public String toString() {
        return String.format("Departamento{id=%d, nombre='%s', empleados=%d, " +
                           "promedioDesempeno=%.2f, totalSalarios=%.2f}", 
                           id, nombre, getNumeroEmpleados(), 
                           calcularPromedioDesempenoDepartamento(), calcularTotalSalariosDepartamento());
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Departamento that = (Departamento) obj;
        return id == that.id;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
