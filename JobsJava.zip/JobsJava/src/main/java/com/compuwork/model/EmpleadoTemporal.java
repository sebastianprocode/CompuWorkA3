package com.compuwork.model;

import java.time.LocalDate;

/**
 * Clase que representa un empleado temporal con contrato a plazo definido.
 * Hereda de Empleado y añade la lógica de gestión de fecha de fin de contrato.
 * 
 * Principio SOLID: Liskov Substitution - Los objetos EmpleadoTemporal pueden 
 * sustituir a objetos Empleado sin alterar el comportamiento del programa.
 */
public class EmpleadoTemporal extends Empleado {
    private LocalDate fechaFinContrato;
    
    /**
     * Constructor de EmpleadoTemporal.
     * @param id Identificador único del empleado
     * @param nombre Nombre completo del empleado
     * @param salarioBase Salario base mensual
     * @param fechaContratacion Fecha de inicio del contrato
     * @param fechaFinContrato Fecha de finalización del contrato
     * @throws IllegalArgumentException si la fecha de fin es anterior a la de inicio
     */
    public EmpleadoTemporal(int id, String nombre, double salarioBase, 
                           LocalDate fechaContratacion, LocalDate fechaFinContrato) {
        super(id, nombre, salarioBase, fechaContratacion);
        
        if (fechaFinContrato.isBefore(fechaContratacion)) {
            throw new IllegalArgumentException("La fecha de fin de contrato no puede ser anterior a la fecha de contratación");
        }
        
        this.fechaFinContrato = fechaFinContrato;
    }
    
    /**
     * Calcula el salario total. Para empleados temporales, 
     * el salario total es igual al salario base (sin bonos).
     * @return Salario base (sin modificaciones)
     */
    @Override
    public double calcularSalarioTotal() {
        return getSalarioBase();
    }
    
    /**
     * Verifica si el contrato del empleado está vigente.
     * @return true si el contrato aún no ha expirado
     */
    public boolean isContratoVigente() {
        return LocalDate.now().isBefore(fechaFinContrato) || LocalDate.now().isEqual(fechaFinContrato);
    }
    
    /**
     * Calcula los días restantes de contrato.
     * @return Días restantes hasta el fin del contrato
     */
    public long getDiasRestantesContrato() {
        if (!isContratoVigente()) {
            return 0;
        }
        return java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), fechaFinContrato);
    }
    
    /**
     * Verifica si el contrato está por expirar (menos de 30 días).
     * @return true si faltan menos de 30 días para el fin del contrato
     */
    public boolean isContratoPorExpirar() {
        return isContratoVigente() && getDiasRestantesContrato() <= 30;
    }
    
    /**
     * Extiende el contrato del empleado.
     * @param nuevaFechaFin Nueva fecha de fin de contrato
     * @throws IllegalArgumentException si la nueva fecha es anterior a la actual
     */
    public void extenderContrato(LocalDate nuevaFechaFin) {
        if (nuevaFechaFin.isBefore(fechaFinContrato)) {
            throw new IllegalArgumentException("La nueva fecha de fin no puede ser anterior a la fecha actual");
        }
        this.fechaFinContrato = nuevaFechaFin;
    }
    
    // Getters y Setters
    public LocalDate getFechaFinContrato() {
        return fechaFinContrato;
    }
    
    public void setFechaFinContrato(LocalDate fechaFinContrato) {
        if (fechaFinContrato.isBefore(getFechaContratacion())) {
            throw new IllegalArgumentException("La fecha de fin de contrato no puede ser anterior a la fecha de contratación");
        }
        this.fechaFinContrato = fechaFinContrato;
    }
    
    @Override
    public String toString() {
        return String.format("EmpleadoTemporal{id=%d, nombre='%s', salarioBase=%.2f, " +
                           "fechaFinContrato=%s, diasRestantes=%d, vigente=%s}", 
                           getId(), getNombre(), getSalarioBase(), 
                           fechaFinContrato, getDiasRestantesContrato(), isContratoVigente());
    }
}
