package com.compuwork.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase abstracta que representa un empleado en el sistema CompuWork.
 * Implementa los atributos y comportamientos básicos comunes a todos los empleados.
 * 
 * Principio SOLID: Single Responsibility - Esta clase solo se encarga de 
 * representar las características básicas de un empleado.
 */
public abstract class Empleado {
    private int id;
    private String nombre;
    private double salarioBase;
    private LocalDate fechaContratacion;
    private List<Integer> evaluacionesDesempeno;
    private Departamento departamento;
    
    /**
     * Constructor de la clase Empleado.
     * @param id Identificador único del empleado
     * @param nombre Nombre completo del empleado
     * @param salarioBase Salario base mensual del empleado
     * @param fechaContratacion Fecha de inicio del contrato
     */
    public Empleado(int id, String nombre, double salarioBase, LocalDate fechaContratacion) {
        this.id = id;
        this.nombre = nombre;
        this.salarioBase = salarioBase;
        this.fechaContratacion = fechaContratacion;
        this.evaluacionesDesempeno = new ArrayList<>();
    }
    
    /**
     * Método abstracto para calcular el salario total.
     * Cada tipo de empleado implementará su propia lógica de cálculo.
     * @return Salario total calculado
     */
    public abstract double calcularSalarioTotal();
    
    /**
     * Agrega una evaluación de desempeño (escala 1-10).
     * @param calificacion Calificación obtenida (1-10)
     * @throws IllegalArgumentException si la calificación no está en el rango válido
     */
    public void agregarEvaluacionDesempeno(int calificacion) {
        if (calificacion < 1 || calificacion > 10) {
            throw new IllegalArgumentException("La calificación debe estar entre 1 y 10");
        }
        this.evaluacionesDesempeno.add(calificacion);
    }
    
    /**
     * Calcula el promedio de desempeño del empleado.
     * @return Promedio de evaluaciones o 0.0 si no hay evaluaciones
     */
    public double calcularPromedioDesempeno() {
        if (evaluacionesDesempeno.isEmpty()) {
            return 0.0;
        }
        return evaluacionesDesempeno.stream()
                .mapToInt(Integer::intValue)
                .average()
                .orElse(0.0);
    }
    
    /**
     * Obtiene la antigüedad del empleado en años.
     * @return Antigüedad en años
     */
    public int getAntiguedadAnios() {
        return LocalDate.now().getYear() - fechaContratacion.getYear();
    }
    
    // Getters y Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public double getSalarioBase() {
        return salarioBase;
    }
    
    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }
    
    public LocalDate getFechaContratacion() {
        return fechaContratacion;
    }
    
    public void setFechaContratacion(LocalDate fechaContratacion) {
        this.fechaContratacion = fechaContratacion;
    }
    
    public List<Integer> getEvaluacionesDesempeno() {
        return new ArrayList<>(evaluacionesDesempeno);
    }
    
    public Departamento getDepartamento() {
        return departamento;
    }
    
    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }
    
    @Override
    public String toString() {
        return String.format("Empleado{id=%d, nombre='%s', salarioBase=%.2f, departamento=%s}", 
                id, nombre, salarioBase, 
                departamento != null ? departamento.getNombre() : "Sin asignar");
    }
}
