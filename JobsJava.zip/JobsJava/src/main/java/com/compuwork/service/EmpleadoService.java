package com.compuwork.service;

import com.compuwork.model.Empleado;
import com.compuwork.model.EmpleadoPermanente;
import com.compuwork.model.EmpleadoTemporal;
import com.compuwork.model.Departamento;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Servicio de gestión de empleados que implementa operaciones CRUD.
 * Utiliza un almacenamiento en memoria para fines de demostración.
 * 
 * Principio SOLID: Dependency Inversion - Depende de abstracciones (interface Empleado)
 * en lugar de implementaciones concretas.
 */
public class EmpleadoService {
    private final Map<Integer, Empleado> empleados;
    private final AtomicInteger idGenerator;
    
    /**
     * Constructor del servicio de empleados.
     * Inicializa el almacenamiento y el generador de IDs.
     */
    public EmpleadoService() {
        this.empleados = new ConcurrentHashMap<>();
        this.idGenerator = new AtomicInteger(1);
    }
    
    /**
     * Crea un nuevo empleado permanente.
     * @param nombre Nombre del empleado
     * @param salarioBase Salario base mensual
     * @param fechaContratacion Fecha de contratación
     * @return Empleado permanente creado
     */
    public Empleado crearEmpleadoPermanente(String nombre, double salarioBase, LocalDate fechaContratacion) {
        int id = idGenerator.getAndIncrement();
        EmpleadoPermanente empleado = new EmpleadoPermanente(id, nombre, salarioBase, fechaContratacion);
        empleados.put(id, empleado);
        return empleado;
    }
    
    /**
     * Crea un nuevo empleado temporal.
     * @param nombre Nombre del empleado
     * @param salarioBase Salario base mensual
     * @param fechaContratacion Fecha de contratación
     * @param fechaFinContrato Fecha de fin de contrato
     * @return Empleado temporal creado
     */
    public Empleado crearEmpleadoTemporal(String nombre, double salarioBase, 
                                        LocalDate fechaContratacion, LocalDate fechaFinContrato) {
        int id = idGenerator.getAndIncrement();
        EmpleadoTemporal empleado = new EmpleadoTemporal(id, nombre, salarioBase, 
                                                       fechaContratacion, fechaFinContrato);
        empleados.put(id, empleado);
        return empleado;
    }
    
    /**
     * Obtiene un empleado por su ID.
     * @param id ID del empleado a buscar
     * @return Optional con el empleado encontrado o vacío si no existe
     */
    public Optional<Empleado> obtenerEmpleadoPorId(int id) {
        return Optional.ofNullable(empleados.get(id));
    }
    
    /**
     * Obtiene todos los empleados registrados.
     * @return Lista de todos los empleados
     */
    public List<Empleado> obtenerTodosLosEmpleados() {
        return new ArrayList<>(empleados.values());
    }
    
    /**
     * Busca empleados por nombre (búsqueda parcial).
     * @param nombre Nombre o parte del nombre a buscar
     * @return Lista de empleados que coinciden con la búsqueda
     */
    public List<Empleado> buscarEmpleadosPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return new ArrayList<>();
        }
        
        String nombreBusqueda = nombre.toLowerCase().trim();
        return empleados.values().stream()
                .filter(emp -> emp.getNombre().toLowerCase().contains(nombreBusqueda))
                .toList();
    }
    
    /**
     * Actualiza los datos de un empleado existente.
     * @param empleado Empleado con los datos actualizados
     * @return true si se actualizó exitosamente, false si no existe
     */
    public boolean actualizarEmpleado(Empleado empleado) {
        if (empleado == null || !empleados.containsKey(empleado.getId())) {
            return false;
        }
        
        empleados.put(empleado.getId(), empleado);
        return true;
    }
    
    /**
     * Actualiza el nombre de un empleado.
     * @param id ID del empleado
     * @param nuevoNombre Nuevo nombre del empleado
     * @return true si se actualizó exitosamente, false si no existe
     */
    public boolean actualizarNombreEmpleado(int id, String nuevoNombre) {
        Optional<Empleado> empleadoOpt = obtenerEmpleadoPorId(id);
        if (empleadoOpt.isPresent()) {
            Empleado empleado = empleadoOpt.get();
            empleado.setNombre(nuevoNombre);
            return true;
        }
        return false;
    }
    
    /**
     * Actualiza el salario base de un empleado.
     * @param id ID del empleado
     * @param nuevoSalarioBase Nuevo salario base
     * @return true si se actualizó exitosamente, false si no existe
     */
    public boolean actualizarSalarioEmpleado(int id, double nuevoSalarioBase) {
        Optional<Empleado> empleadoOpt = obtenerEmpleadoPorId(id);
        if (empleadoOpt.isPresent()) {
            Empleado empleado = empleadoOpt.get();
            empleado.setSalarioBase(nuevoSalarioBase);
            return true;
        }
        return false;
    }
    
    /**
     * Elimina un empleado por su ID.
     * @param id ID del empleado a eliminar
     * @return true si se eliminó exitosamente, false si no existía
     */
    public boolean eliminarEmpleado(int id) {
        Empleado empleadoEliminado = empleados.remove(id);
        if (empleadoEliminado != null && empleadoEliminado.getDepartamento() != null) {
            empleadoEliminado.getDepartamento().eliminarEmpleado(empleadoEliminado);
        }
        return empleadoEliminado != null;
    }
    
    /**
     * Agrega una evaluación de desempeño a un empleado.
     * @param empleadoId ID del empleado
     * @param calificación Calificación (1-10)
     * @return true si se agregó exitosamente, false si no existe el empleado
     */
    public boolean agregarEvaluacionDesempeno(int empleadoId, int calificacion) {
        Optional<Empleado> empleadoOpt = obtenerEmpleadoPorId(empleadoId);
        if (empleadoOpt.isPresent()) {
            empleadoOpt.get().agregarEvaluacionDesempeno(calificacion);
            return true;
        }
        return false;
    }
    
    /**
     * Obtiene el número total de empleados registrados.
     * @return Cantidad de empleados
     */
    public int getTotalEmpleados() {
        return empleados.size();
    }
    
    /**
     * Obtiene empleados por tipo (permanente o temporal).
     * @param esPermanente true para empleados permanentes, false para temporales
     * @return Lista de empleados del tipo especificado
     */
    public List<Empleado> obtenerEmpleadosPorTipo(boolean esPermanente) {
        return empleados.values().stream()
                .filter(emp -> (emp instanceof EmpleadoPermanente) == esPermanente)
                .toList();
    }
    
    /**
     * Transfiere un empleado a un nuevo departamento.
     * @param empleadoId ID del empleado
     * @param nuevoDepartamento Nuevo departamento (puede ser null para desasignar)
     * @return true si se transfirió exitosamente, false si no existe el empleado
     */
    public boolean transferirEmpleado(int empleadoId, Departamento nuevoDepartamento) {
        Optional<Empleado> empleadoOpt = obtenerEmpleadoPorId(empleadoId);
        if (empleadoOpt.isPresent()) {
            Empleado empleado = empleadoOpt.get();
            
            // Remover del departamento actual si existe
            if (empleado.getDepartamento() != null) {
                empleado.getDepartamento().eliminarEmpleado(empleado);
            }
            
            // Asignar al nuevo departamento si no es null
            if (nuevoDepartamento != null) {
                nuevoDepartamento.agregarEmpleado(empleado);
            }
            
            return true;
        }
        return false;
    }
}
