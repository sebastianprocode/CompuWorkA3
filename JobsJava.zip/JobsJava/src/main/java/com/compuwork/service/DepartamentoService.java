package com.compuwork.service;

import com.compuwork.model.Departamento;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Servicio de gestión de departamentos que implementa operaciones CRUD.
 * Utiliza un almacenamiento en memoria para fines de demostración.
 * 
 * Principio SOLID: Interface Segregation - Proporciona solo los métodos 
 * necesarios para la gestión de departamentos.
 */
public class DepartamentoService {
    private final Map<Integer, Departamento> departamentos;
    private final AtomicInteger idGenerator;
    
    /**
     * Constructor del servicio de departamentos.
     * Inicializa el almacenamiento y el generador de IDs.
     */
    public DepartamentoService() {
        this.departamentos = new ConcurrentHashMap<>();
        this.idGenerator = new AtomicInteger(1);
    }
    
    /**
     * Crea un nuevo departamento.
     * @param nombre Nombre del departamento
     * @param descripcion Descripción del departamento
     * @return Departamento creado
     */
    public Departamento crearDepartamento(String nombre, String descripcion) {
        int id = idGenerator.getAndIncrement();
        Departamento departamento = new Departamento(id, nombre, descripcion);
        departamentos.put(id, departamento);
        return departamento;
    }
    
    /**
     * Obtiene un departamento por su ID.
     * @param id ID del departamento a buscar
     * @return Optional con el departamento encontrado o vacío si no existe
     */
    public Optional<Departamento> obtenerDepartamentoPorId(int id) {
        return Optional.ofNullable(departamentos.get(id));
    }
    
    /**
     * Obtiene todos los departamentos registrados.
     * @return Lista de todos los departamentos
     */
    public List<Departamento> obtenerTodosLosDepartamentos() {
        return new ArrayList<>(departamentos.values());
    }
    
    /**
     * Busca departamentos por nombre (búsqueda parcial).
     * @param nombre Nombre o parte del nombre a buscar
     * @return Lista de departamentos que coinciden con la búsqueda
     */
    public List<Departamento> buscarDepartamentosPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return new ArrayList<>();
        }
        
        String nombreBusqueda = nombre.toLowerCase().trim();
        return departamentos.values().stream()
                .filter(dep -> dep.getNombre().toLowerCase().contains(nombreBusqueda))
                .toList();
    }
    
    /**
     * Actualiza los datos de un departamento existente.
     * @param departamento Departamento con los datos actualizados
     * @return true si se actualizó exitosamente, false si no existe
     */
    public boolean actualizarDepartamento(Departamento departamento) {
        if (departamento == null || !departamentos.containsKey(departamento.getId())) {
            return false;
        }
        
        departamentos.put(departamento.getId(), departamento);
        return true;
    }
    
    /**
     * Actualiza el nombre de un departamento.
     * @param id ID del departamento
     * @param nuevoNombre Nuevo nombre del departamento
     * @return true si se actualizó exitosamente, false si no existe
     */
    public boolean actualizarNombreDepartamento(int id, String nuevoNombre) {
        Optional<Departamento> departamentoOpt = obtenerDepartamentoPorId(id);
        if (departamentoOpt.isPresent()) {
            Departamento departamento = departamentoOpt.get();
            departamento.setNombre(nuevoNombre);
            return true;
        }
        return false;
    }
    
    /**
     * Actualiza la descripción de un departamento.
     * @param id ID del departamento
     * @param nuevaDescripcion Nueva descripción del departamento
     * @return true si se actualizó exitosamente, false si no existe
     */
    public boolean actualizarDescripcionDepartamento(int id, String nuevaDescripcion) {
        Optional<Departamento> departamentoOpt = obtenerDepartamentoPorId(id);
        if (departamentoOpt.isPresent()) {
            Departamento departamento = departamentoOpt.get();
            departamento.setDescripcion(nuevaDescripcion);
            return true;
        }
        return false;
    }
    
    /**
     * Elimina un departamento por su ID.
     * @param id ID del departamento a eliminar
     * @return true si se eliminó exitosamente, false si no existía o tiene empleados
     */
    public boolean eliminarDepartamento(int id) {
        Optional<Departamento> departamentoOpt = obtenerDepartamentoPorId(id);
        if (departamentoOpt.isPresent()) {
            Departamento departamento = departamentoOpt.get();
            
            // No permitir eliminar si tiene empleados asignados
            if (departamento.tieneEmpleados()) {
                throw new IllegalStateException("No se puede eliminar un departamento con empleados asignados");
            }
            
            departamentos.remove(id);
            return true;
        }
        return false;
    }
    
    /**
     * Obtiene departamentos sin empleados asignados.
     * @return Lista de departamentos vacíos
     */
    public List<Departamento> obtenerDepartamentosVacios() {
        return departamentos.values().stream()
                .filter(dep -> !dep.tieneEmpleados())
                .toList();
    }
    
    /**
     * Obtiene departamentos con empleados asignados.
     * @return Lista de departamentos con empleados
     */
    public List<Departamento> obtenerDepartamentosConEmpleados() {
        return departamentos.values().stream()
                .filter(Departamento::tieneEmpleados)
                .toList();
    }
    
    /**
     * Obtiene el número total de departamentos registrados.
     * @return Cantidad de departamentos
     */
    public int getTotalDepartamentos() {
        return departamentos.size();
    }
    
    /**
     * Obtiene estadísticas generales de departamentos.
     * @return Array con [total departamentos, con empleados, sin empleados]
     */
    public int[] obtenerEstadisticasDepartamentos() {
        int total = getTotalDepartamentos();
        int conEmpleados = (int) departamentos.values().stream()
                .filter(Departamento::tieneEmpleados)
                .count();
        int sinEmpleados = total - conEmpleados;
        
        return new int[]{total, conEmpleados, sinEmpleados};
    }
    
    /**
     * Verifica si un departamento existe por su ID.
     * @param id ID del departamento a verificar
     * @return true si existe, false si no existe
     */
    public boolean existeDepartamento(int id) {
        return departamentos.containsKey(id);
    }
}
