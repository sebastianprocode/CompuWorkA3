package com.compuwork.service;

import com.compuwork.model.Empleado;
import com.compuwork.model.Departamento;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servicio de generación de reportes de desempeño.
 * Calcula promedios y estadísticas para individuos y departamentos.
 * 
 * Principio SOLID: Single Responsibility - Esta clase solo se encarga de 
 * generar reportes y estadísticas de desempeño.
 */
public class ReporteDesempenoService {
    private final EmpleadoService empleadoService;
    private final DepartamentoService departamentoService;
    
    /**
     * Constructor del servicio de reportes.
     * @param empleadoService Servicio de gestión de empleados
     * @param departamentoService Servicio de gestión de departamentos
     */
    public ReporteDesempenoService(EmpleadoService empleadoService, 
                                  DepartamentoService departamentoService) {
        this.empleadoService = empleadoService;
        this.departamentoService = departamentoService;
    }
    
    /**
     * Genera un reporte de desempeño individual.
     * @param empleadoId ID del empleado
     * @return Reporte individual con estadísticas detalladas
     */
    public ReporteIndividual generarReporteIndividual(int empleadoId) {
        var empleadoOpt = empleadoService.obtenerEmpleadoPorId(empleadoId);
        if (empleadoOpt.isEmpty()) {
            throw new IllegalArgumentException("Empleado no encontrado con ID: " + empleadoId);
        }
        
        Empleado empleado = empleadoOpt.get();
        
        double promedioDesempeno = empleado.calcularPromedioDesempeno();
        double salarioTotal = empleado.calcularSalarioTotal();
        String tipoEmpleado = empleado instanceof com.compuwork.model.EmpleadoPermanente ? 
                              "Permanente" : "Temporal";
        
        return new ReporteIndividual(
            empleado.getId(),
            empleado.getNombre(),
            tipoEmpleado,
            promedioDesempeno,
            empleado.getEvaluacionesDesempeno().size(),
            salarioTotal,
            empleado.getAntiguedadAnios(),
            empleado.getDepartamento() != null ? empleado.getDepartamento().getNombre() : "Sin asignar"
        );
    }
    
    /**
     * Genera un reporte de desempeño por departamento.
     * @param departamentoId ID del departamento
     * @return Reporte departamental con estadísticas agregadas
     */
    public ReporteDepartamental generarReporteDepartamental(int departamentoId) {
        var departamentoOpt = departamentoService.obtenerDepartamentoPorId(departamentoId);
        if (departamentoOpt.isEmpty()) {
            throw new IllegalArgumentException("Departamento no encontrado con ID: " + departamentoId);
        }
        
        Departamento departamento = departamentoOpt.get();
        List<Empleado> empleados = departamento.getEmpleados();
        
        if (empleados.isEmpty()) {
            return new ReporteDepartamental(
                departamento.getId(),
                departamento.getNombre(),
                0,
                0.0,
                0.0,
                0.0,
                0,
                new ArrayList<>()
            );
        }
        
        double promedioDesempeno = departamento.calcularPromedioDesempenoDepartamento();
        double totalSalarios = departamento.calcularTotalSalariosDepartamento();
        double salarioPromedio = totalSalarios / empleados.size();
        
        // Contar empleados por tipo
        long permanentes = empleados.stream()
                .filter(emp -> emp instanceof com.compuwork.model.EmpleadoPermanente)
                .count();
        long temporales = empleados.size() - permanentes;
        
        // Generar reportes individuales para cada empleado
        List<ReporteIndividual> reportesIndividuales = new ArrayList<>();
        for (Empleado empleado : empleados) {
            reportesIndividuales.add(generarReporteIndividual(empleado.getId()));
        }
        
        return new ReporteDepartamental(
            departamento.getId(),
            departamento.getNombre(),
            empleados.size(),
            promedioDesempeno,
            totalSalarios,
            salarioPromedio,
            (int) permanentes,
            reportesIndividuales
        );
    }
    
    /**
     * Genera un reporte general de toda la empresa.
     * @return Reporte general con estadísticas consolidadas
     */
    public ReporteGeneral generarReporteGeneral() {
        List<Empleado> todosEmpleados = empleadoService.obtenerTodosLosEmpleados();
        List<Departamento> todosDepartamentos = departamentoService.obtenerTodosLosDepartamentos();
        
        if (todosEmpleados.isEmpty()) {
            return new ReporteGeneral(
                0,
                0,
                0.0,
                0.0,
                0.0,
                0,
                0,
                new ArrayList<>(),
                new ArrayList<>()
            );
        }
        
        // Estadísticas generales de empleados
        double promedioDesempenoGeneral = todosEmpleados.stream()
                .mapToDouble(Empleado::calcularPromedioDesempeno)
                .average()
                .orElse(0.0);
        
        double totalSalariosGeneral = todosEmpleados.stream()
                .mapToDouble(Empleado::calcularSalarioTotal)
                .sum();
        
        double salarioPromedioGeneral = totalSalariosGeneral / todosEmpleados.size();
        
        // Contar empleados por tipo
        long permanentes = todosEmpleados.stream()
                .filter(emp -> emp instanceof com.compuwork.model.EmpleadoPermanente)
                .count();
        long temporales = todosEmpleados.size() - permanentes;
        
        // Generar reportes departamentales
        List<ReporteDepartamental> reportesDepartamentales = new ArrayList<>();
        for (Departamento departamento : todosDepartamentos) {
            if (departamento.tieneEmpleados()) {
                reportesDepartamentales.add(generarReporteDepartamental(departamento.getId()));
            }
        }
        
        // Top 5 empleados con mejor desempeño
        List<ReporteIndividual> topEmpleados = todosEmpleados.stream()
                .filter(emp -> emp.calcularPromedioDesempeno() > 0)
                .sorted((e1, e2) -> Double.compare(e2.calcularPromedioDesempeno(), e1.calcularPromedioDesempeno()))
                .limit(5)
                .map(emp -> generarReporteIndividual(emp.getId()))
                .toList();
        
        return new ReporteGeneral(
            todosEmpleados.size(),
            todosDepartamentos.size(),
            promedioDesempenoGeneral,
            totalSalariosGeneral,
            salarioPromedioGeneral,
            (int) permanentes,
            (int) temporales,
            reportesDepartamentales,
            topEmpleados
        );
    }
    
    /**
     * Obtiene el ranking de desempeño de todos los empleados.
     * @return Lista de empleados ordenados por desempeño (mayor a menor)
     */
    public List<ReporteIndividual> obtenerRankingDesempeno() {
        return empleadoService.obtenerTodosLosEmpleados().stream()
                .filter(emp -> emp.calcularPromedioDesempeno() > 0)
                .sorted((e1, e2) -> Double.compare(e2.calcularPromedioDesempeno(), e1.calcularPromedioDesempeno()))
                .map(emp -> generarReporteIndividual(emp.getId()))
                .toList();
    }
    
    /**
     * Obtiene estadísticas de desempeño por rango (1-3: Bajo, 4-7: Medio, 8-10: Alto).
     * @return Mapa con distribución de empleados por rango de desempeño
     */
    public Map<String, Integer> obtenerDistribucionDesempeno() {
        Map<String, Integer> distribucion = new HashMap<>();
        distribucion.put("Bajo (1-3)", 0);
        distribucion.put("Medio (4-7)", 0);
        distribucion.put("Alto (8-10)", 0);
        
        for (Empleado empleado : empleadoService.obtenerTodosLosEmpleados()) {
            double promedio = empleado.calcularPromedioDesempeno();
            if (promedio > 0) {
                if (promedio <= 3) {
                    distribucion.put("Bajo (1-3)", distribucion.get("Bajo (1-3)") + 1);
                } else if (promedio <= 7) {
                    distribucion.put("Medio (4-7)", distribucion.get("Medio (4-7)") + 1);
                } else {
                    distribucion.put("Alto (8-10)", distribucion.get("Alto (8-10)") + 1);
                }
            }
        }
        
        return distribucion;
    }
    
    // Clases internas para estructurar los reportes
    
    public static class ReporteIndividual {
        public final int empleadoId;
        public final String nombre;
        public final String tipo;
        public final double promedioDesempeno;
        public final int totalEvaluaciones;
        public final double salarioTotal;
        public final int antiguedadAnios;
        public final String departamento;
        
        public ReporteIndividual(int empleadoId, String nombre, String tipo, double promedioDesempeno,
                               int totalEvaluaciones, double salarioTotal, int antiguedadAnios, String departamento) {
            this.empleadoId = empleadoId;
            this.nombre = nombre;
            this.tipo = tipo;
            this.promedioDesempeno = promedioDesempeno;
            this.totalEvaluaciones = totalEvaluaciones;
            this.salarioTotal = salarioTotal;
            this.antiguedadAnios = antiguedadAnios;
            this.departamento = departamento;
        }
        
        @Override
        public String toString() {
            return String.format("Empleado: %s | Tipo: %s | Desempeño: %.2f | Salario: %.2f | Depto: %s",
                    nombre, tipo, promedioDesempeno, salarioTotal, departamento);
        }
    }
    
    public static class ReporteDepartamental {
        public final int departamentoId;
        public final String nombreDepartamento;
        public final int totalEmpleados;
        public final double promedioDesempeno;
        public final double totalSalarios;
        public final double salarioPromedio;
        public final int empleadosPermanentes;
        public final List<ReporteIndividual> empleados;
        
        public ReporteDepartamental(int departamentoId, String nombreDepartamento, int totalEmpleados,
                                  double promedioDesempeno, double totalSalarios, double salarioPromedio,
                                  int empleadosPermanentes, List<ReporteIndividual> empleados) {
            this.departamentoId = departamentoId;
            this.nombreDepartamento = nombreDepartamento;
            this.totalEmpleados = totalEmpleados;
            this.promedioDesempeno = promedioDesempeno;
            this.totalSalarios = totalSalarios;
            this.salarioPromedio = salarioPromedio;
            this.empleadosPermanentes = empleadosPermanentes;
            this.empleados = empleados;
        }
        
        @Override
        public String toString() {
            return String.format("Departamento: %s | Empleados: %d | Desempeño: %.2f | Salario Promedio: %.2f",
                    nombreDepartamento, totalEmpleados, promedioDesempeno, salarioPromedio);
        }
    }
    
    public static class ReporteGeneral {
        public final int totalEmpleados;
        public final int totalDepartamentos;
        public final double promedioDesempenoGeneral;
        public final double totalSalariosGeneral;
        public final double salarioPromedioGeneral;
        public final int empleadosPermanentes;
        public final int empleadosTemporales;
        public final List<ReporteDepartamental> departamentos;
        public final List<ReporteIndividual> topEmpleados;
        
        public ReporteGeneral(int totalEmpleados, int totalDepartamentos, double promedioDesempenoGeneral,
                            double totalSalariosGeneral, double salarioPromedioGeneral, int empleadosPermanentes,
                            int empleadosTemporales, List<ReporteDepartamental> departamentos,
                            List<ReporteIndividual> topEmpleados) {
            this.totalEmpleados = totalEmpleados;
            this.totalDepartamentos = totalDepartamentos;
            this.promedioDesempenoGeneral = promedioDesempenoGeneral;
            this.totalSalariosGeneral = totalSalariosGeneral;
            this.salarioPromedioGeneral = salarioPromedioGeneral;
            this.empleadosPermanentes = empleadosPermanentes;
            this.empleadosTemporales = empleadosTemporales;
            this.departamentos = departamentos;
            this.topEmpleados = topEmpleados;
        }
        
        @Override
        public String toString() {
            return String.format("=== REPORTE GENERAL ===\n" +
                               "Total Empleados: %d (%d Permanentes, %d Temporales)\n" +
                               "Total Departamentos: %d\n" +
                               "Desempeño Promedio: %.2f\n" +
                               "Salario Promedio: %.2f\n" +
                               "Total Salarios: %.2f",
                    totalEmpleados, empleadosPermanentes, empleadosTemporales,
                    totalDepartamentos, promedioDesempenoGeneral, salarioPromedioGeneral, totalSalariosGeneral);
        }
    }
}
