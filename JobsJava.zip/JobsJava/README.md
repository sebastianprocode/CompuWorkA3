# CompuWork - Sistema de Gestión de Recursos Humanos

## Descripción del Proyecto

CompuWork es un sistema de gestión de Recursos Humanos desarrollado en Java utilizando Programación Orientada a Objetos (POO). El sistema implementa una solución completa para la administración de empleados, departamentos y reportes de desempeño, siguiendo los principios SOLID para garantizar mantenibilidad y escalabilidad.

## Arquitectura del Sistema

### Estructura de Paquetes

```
src/main/java/com/compuwork/
├── model/          # Clases de modelo (POO)
├── service/        # Lógica de negocio y servicios
└── view/           # Interfaz gráfica (Swing)

src/test/java/com/compuwork/
└── test/           # Pruebas unitarias (JUnit 5)
```

### Componentes Principales

#### 1. Modelo de Datos (POO)

**Empleado (Clase Abstracta)**
- Atributos básicos: ID, nombre, salario base, fecha de contratación
- Métodos abstractos para cálculo de salario
- Gestión de evaluaciones de desempeño (escala 1-10)
- Cálculo de promedios y antigüedad

**EmpleadoPermanente (Herencia)**
- Bono por antigüedad (5% por año)
- Beneficios adicionales después de 2 años
- Salario total = salario base + bono antigüedad

**EmpleadoTemporal (Herencia)**
- Gestión de fecha de fin de contrato
- Verificación de vigencia y días restantes
- Salario total = salario base (sin bonos)

**Departamento**
- Gestión de lista de empleados
- Cálculo de estadísticas departamentales
- Operaciones CRUD básicas

#### 2. Lógica de Negocio (Services)

**EmpleadoService**
- Operaciones CRUD completas
- Transferencia entre departamentos
- Gestión de evaluaciones
- Búsqueda y filtrado

**DepartamentoService**
- Administración de departamentos
- Control de restricciones (eliminación con empleados)
- Estadísticas y reportes

**ReporteDesempenoService**
- Reportes individuales, departamentales y generales
- Ranking de desempeño
- Distribución por rangos
- Top 5 mejores empleados

#### 3. Interfaz Gráfica (Swing)

**CompuWorkMainFrame**
- Interfaz intuitiva con pestañas
- Gestión de empleados y departamentos
- Generación y visualización de reportes
- Datos de demostración precargados

## Principios SOLID Implementados

### 1. Single Responsibility Principle (SRP)
- **Empleado**: Solo representa características básicas de empleados
- **Departamento**: Solo gestiona empleados de un departamento específico
- **ReporteDesempenoService**: Solo genera reportes y estadísticas

### 2. Open/Closed Principle (OCP)
- **EmpleadoPermanente/EmpleadoTemporal**: Extienden funcionalidad sin modificar Empleado
- Sistema abierto para nuevos tipos de empleados mediante herencia

### 3. Liskov Substitution Principle (LSP)
- **EmpleadoTemporal**: Puede sustituir a Empleado sin alterar comportamiento
- Todas las subclases son intercambiables con su clase base

### 4. Interface Segregation Principle (ISP)
- **Servicios especializados**: Cada servicio proporciona solo métodos necesarios
- **GUI dividida**: Paneles especializados para cada funcionalidad

### 5. Dependency Inversion Principle (DIP)
- **EmpleadoService**: Depende de abstracción (interface Empleado)
- **ReporteDesempenoService**: Inyecta dependencias de servicios

## Características Técnicas

### Gestión de Empleados
- ✅ Creación de empleados permanentes y temporales
- ✅ Cálculo automático de salarios con bonos
- ✅ Gestión de contratos y vigencia
- ✅ Evaluaciones de desempeño con validación
- ✅ Transferencia entre departamentos

### Gestión de Departamentos
- ✅ CRUD completo de departamentos
- ✅ Asignación y reasignación de empleados
- ✅ Estadísticas departamentales en tiempo real
- ✅ Restricciones de eliminación

### Sistema de Reportes
- ✅ Reportes individuales detallados
- ✅ Reportes departamentales agregados
- ✅ Reporte general de la empresa
- ✅ Ranking de desempeño
- ✅ Distribución por rangos (Bajo/Medio/Alto)

### Pruebas Unitarias
- ✅ Suite completa con JUnit 5
- ✅ Validación de cálculos de salarios
- ✅ Pruebas de asignación de departamentos
- ✅ Verificación de promedios de desempeño
- ✅ Tests de validación y restricciones

## Tecnologías Utilizadas

- **Java 17**: Lenguaje principal
- **Java Swing**: Interfaz gráfica
- **JUnit 5**: Pruebas unitarias
- **Maven**: Gestión de dependencias
- **POO**: Paradigma principal

## Instalación y Ejecución

### Prerrequisitos
- JDK 17 o superior
- Maven 3.6+

### Pasos de Instalación

1. Clonar o descargar el proyecto
2. Navegar al directorio del proyecto
3. Compilar con Maven:
   ```bash
   mvn clean compile
   ```
4. Ejecutar pruebas:
   ```bash
   mvn test
   ```
5. Ejecutar aplicación:
   ```bash
   mvn exec:java -Dexec.mainClass="com.compuwork.view.CompuWorkMainFrame"
   ```

## Uso de la Aplicación

### 1. Gestión de Empleados
- Complete el formulario con datos del empleado
- Seleccione tipo (Permanente/Temporal)
- Para temporales, especifique fecha de fin de contrato
- Asigne a un departamento existente
- Use los botones para agregar, actualizar o eliminar

### 2. Gestión de Departamentos
- Cree nuevos departamentos con nombre y descripción
- Los empleados se asignan automáticamente al transferir
- No se pueden eliminar departamentos con empleados asignados

### 3. Reportes de Desempeño
- Seleccione tipo de reporte (Individual/Departamental/General)
- Elija el empleado o departamento específico
- Visualice estadísticas detalladas en el área de reportes

## Datos de Demostración

La aplicación incluye datos precargados para demostración:
- **3 Departamentos**: Tecnología, Recursos Humanos, Ventas
- **3 Empleados**: Mix de permanentes y temporales
- **Evaluaciones**: Ejemplos de calificaciones de desempeño

## Arquitectura de Datos

### Flujo de Integración

1. **Model Layer**: Clases POO con validaciones y lógica de negocio básica
2. **Service Layer**: Operaciones CRUD, reglas de negocio, orquestación
3. **View Layer**: Interfaz Swing que consume los servicios
4. **Test Layer**: Validación completa de funcionalidades

### Manejo de Dependencias
- Inyección de dependencias manual en constructores
- Servicios desacoplados y reutilizables
- Fácil extensión para nuevos componentes

## Mejoras Futuras

### Posibles Extensiones
- Persistencia con base de datos (JPA/Hibernate)
- API REST con Spring Boot
- Autenticación y autorización
- Reportes en PDF/Excel
- Notificaciones automáticas (contratos por expirar)
- Integración con sistemas de nómina

### Escalabilidad
- Arquitectura modular permite fácil adición de nuevos tipos de empleados
- Servicios independientes para escalado horizontal
- Interfaz desacoplada para migración a otras tecnologías

## Licencia

Este proyecto es para fines educativos y demostrativos de arquitectura de software y principios POO.

---

**Nota**: Los errores de compilación mostrados en el IDE son normales y se deben a la configuración del entorno. El código está diseñado para compilarse correctamente con Maven y las dependencias especificadas en el archivo pom.xml.
